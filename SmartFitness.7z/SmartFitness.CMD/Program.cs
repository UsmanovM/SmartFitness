﻿using SmartFitness.BL.Controller;
using SmartFitness.BL.Model;
using System;

namespace SmartFitness.CMD
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Вас приветствует приложение SmartFitness!");

            Console.WriteLine("Введите имя пользователя");
            var name = Console.ReadLine();

            Console.WriteLine("Введите пол");
            var gender = Console.ReadLine();

            Console.WriteLine("Введите дату рождения");
            var birthDay = DateTime.Parse(Console.ReadLine()); //TODO: переписать на TryParse

            Console.WriteLine("Введите вес");
            var weight = Double.Parse(Console.ReadLine());

            Console.WriteLine("Введите рост");
            var height = Double.Parse(Console.ReadLine()); 

            var userController = new UserController(name, gender, birthDay, weight, height);
            userController.Save();

            Console.ReadLine();
        }
    }
}
