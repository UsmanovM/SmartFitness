﻿using SmartFitness.BL.Model;
using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace SmartFitness.BL.Controller
{
    /// <summary>
    /// Контроллер пользователя.
    /// </summary>
    public class UserController
    {
        /// <summary>
        /// Пользователь приложения.
        /// </summary>
        public User User { get; set; }   // не set;  

        /// <summary>
        /// Создание нового контроллера пользователя приложения.
        /// </summary>
        public UserController(string userName, string genderName, DateTime birthDay, double weight, double height)
        {

            // TODO: Проверка

            var gender = new Gender(genderName);
            User = new User(userName, gender, birthDay, weight, height);

        }

        public UserController()
        {
            var formatter = new BinaryFormatter();
            using (var fs = new FileStream("user.dat", FileMode.OpenOrCreate))
            {
                User user = formatter.Deserialize(fs) as User;

                if (user == null)
                {
                    //throw new ArgumentNullException("Пользователь не может быть null"); //nameof

                    //TODO: Что делать если пользователя не прочитали? 
                }

                User = user;

                //User = user ?? throw new ArgumentNullException("Пользователь не может быть null"); //nameof
            }
        }

        /// <summary>
        /// Сохранить данные пользователя.
        /// </summary>
        public void Save()
        {
            var formatter = new BinaryFormatter();
            using (var fs = new FileStream("users.dat", FileMode.OpenOrCreate))
            {
                formatter.Serialize(fs, User);
            }
        }



    }
}
